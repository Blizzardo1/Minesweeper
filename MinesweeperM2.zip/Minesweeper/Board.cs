﻿using System.Drawing;

namespace Minesweeper
{
    /// <summary>
    /// Minesweeper Game Board
    /// </summary>
    internal class Board {
        private const int CellWidth = 4;
        private const int CellPadding = -1;

        private const ConsoleColor FrameColor = ConsoleColor.DarkGray;
        private const ConsoleColor CoordColor = ConsoleColor.Cyan;

        private Size _size;
        private Cell[,] _cells;
        private double _difficulty;
        private int _bombCount;
        private int _safeCells;


        /// <summary>
        /// Level of difficulty
        /// </summary>
        public double Difficulty
        {
            get => _difficulty;
            set => _difficulty = value > 0.9d ? 0.9d : Math.Round(value, 1) < 0.1 ? 0.1d : Math.Round(value, 1);
        }

        /// <summary>
        /// Instantiates a new Game Board
        /// </summary>
        /// <param name="size">The size of the board</param>
        /// <param name="difficulty">The difficulty of the game</param>
        public Board(Size size, double difficulty = 0.2) {
            _size = size;
            Difficulty = difficulty;
            _cells = new Cell[size.Width, size.Height];
        }

        /// <summary>
        /// Builds a new Board
        /// </summary>
        public void SetupLiveNeighbors()
        {
            var rand = new Random();
            int bombsGenerated = 0;
            for (int row = 0; row < _size.Width; row++)
            {
                for (int col = 0; col < _size.Height; col++) {
                    double g = rand.NextDouble();
                    bool bomb = g < _difficulty;
                    bombsGenerated = bomb ? bombsGenerated + 1 : bombsGenerated;
                    _cells[row, col] = new Cell(row, col, bomb);
                }
            }
            _bombCount = bombsGenerated;
            _safeCells = _size.MultiplySize() - _bombCount;
        }

        /// <summary>
        /// Calculate all the bombs "live neighbors" across the board.
        /// </summary>
        public void CalculateLiveNeighbors()
        {
            for (int row = 0; row < _size.Height; row++)
            {
                for (int column = 0; column < _size.Width; column++)
                {
                    int liveNeighborCount = 0;

                    if (_cells[row, column].LiveBomb)
                    {
                        // If the cell itself is live, set the neighbor count to -1
                        // It's a bomb, made in a factory, a Bomb Factory.
                        _cells[row, column].LiveNeighbors = 9;
                        continue;
                    }

                    // Check the surrounding cells for live bombs
                    for (int i = row - 1; i <= row + 1; i++)
                    {
                        for (int j = column - 1; j <= column + 1; j++) {
                            if (i < 0 || i >= _size.Height || j < 0 || j >= _size.Width) continue;
                            if (!_cells[ i, j ].LiveBomb) continue;
                            liveNeighborCount++;
                        }
                    }

                    _cells[row, column].LiveNeighbors = liveNeighborCount;
                }
            }
        }

        /// <summary>
        /// Inputs the user's move and marks a cell as visited
        /// </summary>
        /// <param name="row">The Row</param>
        /// <param name="column">The Column</param>
        public void SelectCell(int row, int column) {
            Cell c = _cells[ row, column ];
            if (c.LiveBomb) {
                Console.WriteLine("You hit a bomb!");
                _cells.VisitBombs();
                PrintBoard();
                GameOver();
                return;
            }

            // Automatically mark all the cells around this one as visited if neighbors are less than 2
            // This is a recursive function
            VisitNeighbors(c);


            _cells[ row, column ].Visited = true;
        }
        

        /// <summary>
        /// Game Over, Sorry!
        /// </summary>
        private void GameOver() {
            Console.Title = "Game Over";
            Console.Write("Press any key to start a new game...");
            Console.ReadKey(true);
            Reset();
        }

        /// <summary>
        /// Visits all the neighbors of a cell if the cell has less than (difficulty * 10) neighbors
        /// </summary>
        /// <param name="cell">The cell to check surrounding neighbors</param>
        private void VisitNeighbors(Cell cell) {
            // Live neighbors and difficulty Multiplier are the same
            if (cell.LiveNeighbors > (int)Math.Round(_difficulty * 10)) return;
            cell.Visited = true;
            for (int i = cell.Row - 1; i <= cell.Row + 1; i++) {
                for (int j = cell.Column - 1; j <= cell.Column + 1; j++) {
                    if (i < 0 || i >= _size.Height || j < 0 || j >= _size.Width) continue;
                    if (_cells[ i, j ].Visited) continue;
                    VisitNeighbors(_cells[ i, j ]);
                }
            }
        }

        /// <summary>
        /// Resets the board.
        /// </summary>
        public void Reset() {
            Console.Title = Program.GameName;
            _cells = null!;
            _cells = new Cell[_size.Width, _size.Height];
            SetupLiveNeighbors();
            CalculateLiveNeighbors();
        }

        /// <summary>
        /// Allows resize of the board
        /// </summary>
        /// <param name="newSize">The new size of the board.</param>
        public void Resize(Size newSize) {
            _size = newSize;
        }

        /// <summary>
        /// Generates a Character row for the entire board
        /// </summary>
        /// <param name="length">The length of which to generate</param>
        /// <param name="even">Character for even cells</param>
        /// <param name="odd">Character for odd cells</param>
        /// <returns>An alternating row of characters</returns>
        private static string GenerateRow(int length, char even, char odd)
        {
            string str = "";

            for (int i = 0; i < length; i++) {
                str += i % CellWidth < CellWidth - 1 ? even : odd;
            }

            return str;
        }

        /// <summary>
        /// Prints with a specified foregroundColor
        /// </summary>
        /// <param name="obj">The <see cref="object"/> to print out</param>
        /// <param name="foregroundColor">The foreground <see cref="ConsoleColor"/>.</param>
        private static void Print(object obj, ConsoleColor foregroundColor = ConsoleColor.White) {
            Console.ForegroundColor = foregroundColor;
            Console.Write(obj);
            Console.ResetColor();
        }

        /// <summary>
        /// Prints the Board
        /// </summary>
        public void PrintBoard() {
            Console.WriteLine($"Difficulty {_difficulty * 10}");

            Print(" "); // This is for the start of the Column Coordinate
            for(int c = 0; c < _size.Width + 1; c++) {
                // A simple dirty hack, Create a space where there is no column present
                // for the game. Quick, dirty, and needs fixing so each column and row
                // number are tabular. That meaning the blank spot has no border.
                Print($"{(c == 0 ? $"  " : c-1 > 9 ? $"{c - 1,1}" : $" {c - 1,-1}")} ", CoordColor);
                Print(" ", FrameColor);
            }

            Console.WriteLine();

            // Top Row Generation
            
            // Dirty hack; 
            for (int row = 0; row < _size.Height; row++) {
                // Begin each row with a border line generated to conform to the physical board
                Print(row == 0 
                    ? $"    ╔{GenerateRow(_size.Width * CellWidth + CellPadding, '═', '╦')}╗\n"
                    : $"    ╠{GenerateRow(_size.Width * CellWidth + CellPadding, '═', '╬')}╣\n", FrameColor);

                // The row hack; essentially, this will shift the numbers around
                // if greater than 9. 
                Print(" ", FrameColor);
                Print($"{( row > 9 ? $"{row} " : $" {row} " )}", CoordColor);

                for (int column = 0; column < _size.Width; column++)
                {
                    // Each Column has this for a starting character, then the cell data, then an ending char.
                    Print("║ ", FrameColor);

                    // Unused. This eventually will get implemented.
                    // We don't want to know where the bombs are physically,
                    // we need to guess and if we happen to hit a bomb, game over.
                    if (_cells[row, column].Visited)
                    {
                        if (_cells[row, column].LiveBomb)
                        {
                            Print("×", ConsoleColor.Red); // Display live cell
                        }
                        else
                        {
                            Print(_cells[row, column], ConsoleColor.Green); // Display live neighbor count
                        }
                    }
                    else
                    {
                        Console.Write("?");
                    }
                    Print(" ");
                }
                Print("║\n", FrameColor);
            }

            // The bottom of the board frame
            Print($"    ╚{GenerateRow(_size.Width * CellWidth + CellPadding, '═', '╩')}╝\n", FrameColor);
        }

        /// <summary>
        /// Checks if the game is over (all cells are visited)
        /// </summary>
        public void CheckWin() {
            int winCheck = 0;
            
            for (int row = 0; row < _cells.GetLength(0); row++) {
                for(int col = 0; col < _cells.GetLength(1); col++) {
                    winCheck += (_cells[ row, col ] is { Visited: false}) ? 1 : 0;
                }
            }

            Console.WriteLine("");
            if (winCheck != _bombCount) return;
            Console.WriteLine(Faces.Cool);
            Console.WriteLine("You win!");
            GameOver();
        }
    }
}
