﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minesweeper
{
    internal class Cell {
        private int _row;
        private int _column;
        private bool _liveBomb;
        private int _liveNeighbors;
        private bool _visited;

        public int Row
        {
            get => _row;
            set => _row = value;
        }

        public int Column
        {
            get => _column;
            set => _column = value;
        }

        public bool LiveBomb
        {
            get => _liveBomb;
            set => _liveBomb = value;
        }

        public int LiveNeighbors {
            get => _liveNeighbors;
            set => _liveNeighbors = value;
        }

        public bool Visited
        {
            get => _visited;
            set => _visited = value;
        }

        public Cell(int row, int col, bool live) {
            _row = row;
            _column = col;
            _liveBomb = live;
        }

        #region Overrides of Object

        /// <inheritdoc />
        public override string ToString() {

            return _liveNeighbors.ToString();
        }

        #endregion
    }
}
