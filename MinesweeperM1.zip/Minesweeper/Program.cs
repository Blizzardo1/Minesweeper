﻿using System.ComponentModel.Design;
using System.Drawing;
using System.Text;

namespace Minesweeper
{
    internal static class Program {
        private static Board? _board;

        private static void Help()
        {
            Console.WriteLine("\nC > Decrease Difficulty by 1 and resets the game");
            Console.WriteLine("D > Increase Difficulty by 1 and resets the game");
            Console.WriteLine("H > This Help");
            Console.WriteLine("? > This Help");
            Console.WriteLine("R > Reset Board");
            Console.WriteLine("Q > Exit");
            Thread.Sleep(2000);
        }
        
        private static void Main(string[] args) {
            Console.Title = "Toaster Network's Minesweeper";

            Console.CursorVisible = false;
            Console.WriteLine("Welcome to Minesweeper!");
            Help();
            _board = new Board(new Size(12, 12));
            _board.Reset();
            
            while (true)
            {
                // Do loop stuff here
                Console.Clear();
                _board.PrintBoard();
                Console.Write("Input> ");
                string request = Console.ReadLine()!;
                if(request.IsEmpty()) continue;
                try {
                    // To prevent a "feature", Grab the first two values
                    // and either ignore the rest or be explicit and throw an error
                    if (request.Contains(',')) {
                        // Might as well ignore the rest
                        char[] values = request.ToCharArray(0, 3);
                        if (!char.IsNumber(values[ 0 ]) || !char.IsNumber(values[ 2 ])) {
                            throw new ArgumentException("Must be x,y number coordinates.");
                        }
                        continue;
                    }

                    Action a = request.ToLower() switch {
                        "q" => () => Environment.Exit(0),
                        "r" => _board.Reset,
                        "d" => () => { _board.Difficulty += 0.1;_board.Reset(); },
                        "c" => () => { _board.Difficulty -= 0.1;_board.Reset(); },
                        "h" or "?" => Help,
                        _ => () => throw new ArgumentException("Invalid selection.")
                    };
                    a();
                    Console.SetCursorPosition(0, 0);
                }catch (Exception ex) {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(ex.Message);
                    Console.ResetColor();
                    Thread.Sleep(1500);
                }
            }
        }
    }
}