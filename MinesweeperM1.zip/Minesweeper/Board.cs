﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minesweeper
{
    /// <summary>
    /// Minesweeper Game Board
    /// </summary>
    internal class Board {
        private const int CellWidth = 4;
        private const int CellPadding = -1;

        private readonly ConsoleColor _frameColor = ConsoleColor.DarkGray;
        private readonly ConsoleColor _coordColor = ConsoleColor.Cyan;

        private Size _size;
        private Cell[,] _cells;
        private double _difficulty;
        

        /// <summary>
        /// Level of difficulty
        /// </summary>
        public double Difficulty
        {
            get => _difficulty;
            set => _difficulty = value > 0.9d ? 0.9d : Math.Round(value, 1) < 0.1 ? 0.1d : Math.Round(value, 1);
        }

        /// <summary>
        /// Instantiates a new Game Board
        /// </summary>
        /// <param name="size">The size of the board</param>
        /// <param name="difficulty">The difficulty of the game</param>
        public Board(Size size, double difficulty = 0.2) {
            _size = size;
            Difficulty = difficulty;
            _cells = new Cell[size.Width, size.Height];
        }

        /// <summary>
        /// Builds a new Board
        /// </summary>
        public void SetupLiveNeighbors()
        {
            var rand = new Random();
            int c = 0;
            for (int row = 0; row < _size.Width; row++)
            {
                for (int col = 0; col < _size.Height; col++) {
                    double g = rand.NextDouble();
                    bool bomb = g < _difficulty;
                    c = bomb ? c + 1 : c;
                    _cells[row, col] = new Cell(row, col, bomb);
                    _cells[row, col].Visited = true; // Demo, triggers Visitation
                }
            }
            Console.WriteLine($"Total bombs: {c}");
        }

        /// <summary>
        /// Calculate all the bombs "live neighbors" across the board.
        /// </summary>
        public void CalculateLiveNeighbors()
        {
            for (int row = 0; row < _size.Height; row++)
            {
                for (int column = 0; column < _size.Width; column++)
                {
                    int liveNeighborCount = 0;

                    if (_cells[row, column].LiveBomb)
                    {
                        // If the cell itself is live, set the neighbor count to 9
                        _cells[row, column].LiveNeighbors = 9;
                        continue;
                    }

                    // Check the surrounding cells for live bombs
                    for (int i = row - 1; i <= row + 1; i++)
                    {
                        for (int j = column - 1; j <= column + 1; j++) {
                            if (i < 0 || i >= _size.Height || j < 0 || j >= _size.Width) continue;
                            if (!_cells[ i, j ].LiveBomb) continue;
                            liveNeighborCount++;
                        }
                    }

                    _cells[row, column].LiveNeighbors = liveNeighborCount;
                }
            }
        }

        /// <summary>
        /// Resets the board.
        /// </summary>
        public void Reset() {
            _cells = null!;
            _cells = new Cell[_size.Width, _size.Height];
            SetupLiveNeighbors();
            CalculateLiveNeighbors();
        }

        /// <summary>
        /// Generates a Character row for the entire board
        /// </summary>
        /// <param name="length">The length of which to generate</param>
        /// <param name="even">Character for even cells</param>
        /// <param name="odd">Character for odd cells</param>
        /// <returns>An alternating row of characters</returns>
        private string GenerateRow(int length, char even, char odd)
        {
            string str = "";

            for (int i = 0; i < length; i++) {
                str += i % CellWidth < CellWidth - 1 ? even : odd;
            }

            return str;
        }

        private static void Print(object obj, ConsoleColor color = ConsoleColor.White) {
            Console.ForegroundColor = color;
            Console.Write(obj);
            Console.ResetColor();
        }

        /// <summary>
        /// Prints the Board
        /// </summary>
        public void PrintBoard() {
            Console.WriteLine($"Difficulty {_difficulty * 10}");

            
            Print(" "); // This is for the start of the Column Coordinate
            for(int c = 0; c < _size.Width + 1; c++) {
                // A simple dirty hack, Create a space where there is no column present
                // for the game. Quick, dirty, and needs fixing so each column and row
                // number are tabular. That meaning the blank spot has no border.
                Print($"{(c == 0 ? $"  " : c-1 > 9 ? $"{c - 1,1}" : $" {c - 1,-1}")} ", _coordColor);
                Print(" ", _frameColor);
            }

            Console.WriteLine();

            // Top Row Generation
            
            // Dirty hack; 
            for (int row = 0; row < _size.Height; row++) {
                // Begin each row with a border line generated to conform to the physical board
                Print(row == 0 
                    ? $"    ╔{GenerateRow(_size.Width * CellWidth + CellPadding, '═', '╦')}╗\n"
                    : $"    ╠{GenerateRow(_size.Width * CellWidth + CellPadding, '═', '╬')}╣\n", _frameColor);

                // The row hack; essentially, this will shift the numbers around
                // if greater than 9. 
                Print(" ", _frameColor);
                Print($"{( row > 9 ? $"{row} " : $" {row} " )}", _coordColor);

                for (int column = 0; column < _size.Width; column++)
                {
                    // Each Column has this for a starting character, then the cell data, then an ending char.
                    Print("║ ", _frameColor);
                    // Unused. This eventually will get implemented.
                    // We don't want to know where the bombs are physically,
                    // we need to guess and if we happen to hit a bomb, game over.
                    if (_cells[row, column].Visited)
                    {
                        if (_cells[row, column].LiveBomb)
                        {
                            Print("×", ConsoleColor.Red); // Display live cell
                        }
                        else
                        {
                            Print(_cells[row, column], ConsoleColor.Green); // Display live neighbor count
                        }
                    }
                    else
                    {
                        // Not checking for unvisited cells. This is a demonstration of the
                        // algorithm used to generate the field.
                        Console.Write(_cells[row, column]); // Display live neighbor count; DEMO
                    }
                    Print(" ");
                }
                Print("║\n", _frameColor);
            }

            // The bottom of the board frame
            Print($"    ╚{GenerateRow(_size.Width * CellWidth + CellPadding, '═', '╩')}╝\n", _frameColor);
        }
    }
}
