﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Winsweeper
{
    internal static class Extensions
    {
        public static string GetDescription(this Enum value)
        {
            FieldInfo? fi = value.GetType().GetField(value.ToString());
            DescriptionAttribute[]? attributes = fi?.GetCustomAttributes(typeof(DescriptionAttribute), false) as DescriptionAttribute[];
            return attributes?.FirstOrDefault()?.Description ?? value.ToString();
        }

        public static string Format(this TimeSpan ts)
        {
            var sb = new StringBuilder();

            if (ts.Hours > 0)
            {
                sb.Append($"{ts.Hours} {(ts.Hours > 1 ? "hours" : "hour")} ");
            }

            if (ts.Minutes > 0)
            {
                sb.Append($" {ts.Minutes} {(ts.Minutes > 1 ? "minutes" : "minute")} ");
            }

            if (ts.Seconds > 0)
            {
                sb.Append($" {ts.Seconds} {(ts.Seconds > 1 ? "seconds" : "second")} ");
            }

            return sb.ToString();
        }
    }
}
