﻿using Libsweeper;
using SDL2;
using Color = SDL2.Color;
using Point = SDL2.Point;
using Timer = System.Timers.Timer;

namespace SDLsweeper
{
    internal class Game : IGameObject {
        private const int CellSize = 32;
        private const int XOffset = 10;
        private const int YOffset = 10;
        private const int LocationX = 100;
        private const int LocationY = 100;

        private Board _board;
        private Size _cellSize;

        private IntPtr _window;
        private IntPtr _renderer;

        private List< IGameObject > _tiles;

        /// <summary>
        /// Creates a new Game
        /// </summary>
        /// <param name="size">The Size of the board</param>
        /// <param name="difficulty">The difficulty from 1 to 9</param>
        public Game(int difficulty) {
            _board = new Board(new Size(10 + difficulty * 2, 10 + difficulty * 2), (double)difficulty / 10);
            _cellSize = new Size(CellSize, CellSize);
            _tiles = new List< IGameObject >();

            _window = SDL.CreateWindow("Minesweeper", LocationX, LocationY, 
                _board.Size.Width * CellSize + XOffset * 2,
                _board.Size.Height * CellSize + YOffset * 2,
                WindowFlags.AllowHighdpi | WindowFlags.Resizable | WindowFlags.Shown);

            if(_window == IntPtr.Zero) {
                throw new Exception("Cannot create Window");
            }
            
            _renderer = SDL.CreateRenderer(_window, -1, RendererFlags.Accelerated);

            if(_renderer == IntPtr.Zero) {
                throw new Exception("Cannot create Renderer");
            }
            

            IsRunning = true;
        }

        public bool IsRunning { get; set; }

        public void Start()
        {
            _board.Reset();
            NewGame();
            //_timer.Start();
        }

        private void Background(Color color) {
            _ = SDL.SetRenderDrawColor(_renderer, color.R, color.G, color.B, color.A);
        }

        #region Implementation of IGameObject

        /// <inheritdoc />
        public void Draw() {
            Background(new Color { A = 255, B = 23, G = 23, R = 23 });
            _ = SDL.RenderClear(_renderer);
            foreach(CellTile? cell in _tiles.Cast<CellTile?>())
            {
                cell!.Draw();
            }
        }

        /// <inheritdoc />
        public void Update() { 
            
            while (SDL.PollEvent(out Event e) >= 1)
                if(e.Quit.Type == EventType.Quit)
                {
                    SDL.DestroyRenderer(_renderer);
                    SDL.DestroyWindow(_window);
                    SDL.Quit();
                    IsRunning = false;
                }
            
                foreach (CellTile? cell in _tiles.Cast< CellTile? >()) {
                    cell!.Update();
                }
            CheckWin();
        }

        #endregion

        private void CheckWin()
        {
            if (!_board.CheckWin()) return;
            // new GameDialog(Resources.Cool, "You won!", "Congratulations!").ShowDialog(this);
            _board.Reset();
            NewGame();
        }

        private void NewGame()
        {
            // Text = "Minesweeper";
            // Clear Contents and restart
            _tiles.Clear();

            for (int y = 0; y < _board.Size.Height; y++)
            {
                for (int x = 0; x < _board.Size.Width; x++) {
                    CellTile c = new(_board.Cells[y,x], _renderer);
                    _tiles.Add(c);
                }
            }
        }

        private void Cell_Click(object? sender, MouseEventArgs e)
        {
            if (sender is not Button b) return;
            if (b.Tag is not Cell c) return;
            switch (e.Button)
            {
                case MouseButtons.Right:
                    // Add more logic to turn a flag into a question
                    c.Flagged = !c.Flagged;
                    return;
                case MouseButtons.Left:
                    SelectCell(c);
                    return;
                case MouseButtons.None:
                    break;
                case MouseButtons.Middle:
                    break;
                case MouseButtons.XButton1:
                    break;
                case MouseButtons.XButton2:
                    break;
                default:
                    return;
            }
        }

        /// <summary>
        /// Inputs the user's move and marks a cell as visited
        /// </summary>
        /// <param name="cell">The cell to mark</param>
        private void SelectCell(Cell cell)
        {
            if (cell.Flagged) return;

            if (cell.LiveBomb)
            {
                _board.Cells.VisitBombs();
                GameOver();
                return;
            }

            // Automatically mark all the cells around this one as visited if neighbors are less than 2
            // This is a recursive function
            _board.VisitNeighbors(cell);


            cell.Visited = true;
        }

        /// <summary>
        /// Game Over, Sorry!
        /// </summary>
        private void GameOver()
        {
            // Game Over
            
            // Display Message
            //new GameDialog(Resources.Boom, "Oh no! You have just stepped on a mine!\nBUMMER!", "Game Over!").ShowDialog(this);
            _board.Reset();
            NewGame();

        }
    }
}
