﻿using Libsweeper;
using SDL2;
using static SDL2.SDL;

namespace SDLsweeper; 

internal class CellTile : IGameObject {
    private const int CellSize = 32;
    private readonly Cell _cell;
    private readonly IntPtr _renderer;
    private Rect _rect;

    /// <summary>
    /// Creates a new Cell Tile
    /// </summary>
    /// <param name="cell">A Reference to a Cell</param>
    /// <param name="renderer">A pointer to a renderer</param>
    public CellTile(Cell cell , IntPtr renderer)
    {
        _cell = cell;
        _renderer = renderer;
        _rect = new Rect { X = _cell.Column, Y = _cell.Row, W = CellSize, H = CellSize };
    }

    #region Implementation of IGameObject

    /// <inheritdoc />
    public void Draw() {
        SetRenderDrawColor(_renderer, 0, 128, 0, 255);
        int renderFillRect = RenderFillRect(_renderer, ref _rect);
        if (_cell.Flagged)
        {
            // Draw Flag
            return;
        }

        if (_cell.Visited)
        {
            // Draw Number
            return;
        }

        // Draw Untouched Square
    }

    /// <inheritdoc />
    public void Update() {
        // Update Mouse Events here
        if (_cell.Flagged)
        {
            // If Flag, unflag or question mark
            return;
        }
        
        if (_cell.Visited)
        {
            // Ignore, already selected
            return;
        }
        
        // It's Untouched Square, Select
        
    }

    #endregion
}